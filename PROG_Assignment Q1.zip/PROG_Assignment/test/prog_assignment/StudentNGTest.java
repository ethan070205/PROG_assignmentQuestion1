/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package prog_assignment;

import java.io.ByteArrayInputStream;
import static org.testng.Assert.*;
import org.testng.annotations.Test;

/**
 *
 * @author User
 */
public class StudentNGTest {
    
    public StudentNGTest() {
    }

    @Test
    public void TestSaveStudent() 
    {
         Student st = new Student();
         st.setName("Name123");
         st.setId(123);
         st.setCourse("course123");
         st.setAge(16);
         st.setEmail("email@gmail.com");
         
        assertEquals(  "Name123", Student.getName());
        assertEquals( 16 ,Student.getAge());
        assertEquals( "course123",Student.getCourse() );
        assertEquals( "email@gmail.com" ,Student.getEmail());
        assertEquals(123 ,Student.getId() );       
    }
    
    @Test
    public void TestSearchStudent(){
    Student st = new Student();
    
    st.setName("Name123");
         st.setId(123);
         st.setCourse("course123");
         st.setAge(16);
         st.setEmail("email@gmail.com");

    
    ByteArrayInputStream In = new ByteArrayInputStream("123".getBytes());
    System.setIn(In);
   boolean outcome = st.studentSearch();
   assertTrue(outcome);
   
    }
    
    
    @Test
    public void TestSearchStudent_StudentNotFound()
    {
        Student st = new Student();
         st.setName("Name123");
         st.setId(123);
         st.setCourse("course123");
         st.setAge(16);
         st.setEmail("email@gmail.com");
    
    
    ByteArrayInputStream In = new ByteArrayInputStream("543".getBytes());
    System.setIn(In);
    boolean outcome = st.studentSearch();
    assertTrue(outcome);
    }
    
    @Test
    public void TestDeleteStudent()
    {
         Student st = new Student();
         st.setName("Name123");
         st.setId(123);
         st.setCourse("course123");
         st.setAge(16);
         st.setEmail("email@gmail.com");
    
    
    ByteArrayInputStream In = new ByteArrayInputStream("543".getBytes());
    System.setIn(In);
    boolean outcome = st.studentSearch();
    Student.delete = true;
    assertTrue(Student.delete);
        
        
         
    }
    
    @Test
    public void TestDeleteStudent_StudentNotFound()
    {
        Student st = new Student();
         st.setName("Name123");
         st.setId(123);
         st.setCourse("course123");
         st.setAge(16);
         st.setEmail("email@gmail.com");
         
   ByteArrayInputStream In = new ByteArrayInputStream("123".getBytes());
    System.setIn(In);
   boolean outcome = st.studentSearch();
   assertTrue(outcome);
    }
    
    @Test
    public void TestStudentAge_StudentAgeValid()
    {
         Student st = new Student();
         assert Student.getAge() > 15;
                 
    }
    
    @Test 
    public void TestStudentAge_StudentAgeInvalid()
    {
         Student st = new Student();
         assertFalse( Student.getAge() < 16);
    }
    
    @Test
    public void TestStudentAge_StudentAgeInvalidCharacter()
    {
        boolean invalid  = false;
      Student st = new Student();
      assertFalse(Student.AGE);

    }
    
   @Test
   public void TestStudentReport()
   {
       System.out.println("STUDENT REPORT");
       Student st = new Student();
       Student.studentReport();
   }
    

    
}
