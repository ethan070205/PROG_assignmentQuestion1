/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog_assignment;

import java.util.Scanner;
import static prog_assignment.PROG_Assignment.Count;
import static prog_assignment.PROG_Assignment.ID;
import static prog_assignment.PROG_Assignment.age;
import static prog_assignment.PROG_Assignment.course;
import static prog_assignment.PROG_Assignment.email;
import static prog_assignment.PROG_Assignment.name;
import static prog_assignment.PROG_Assignment.studentCount;
import static prog_assignment.PROG_Assignment.userInput;

/**
 *
 * @author User
 */
public class Student {
   private static String Name;
   public static int Age;
   private static String Course;
   private static String Email;
   private static int Id;
   public static boolean AGE;
   public static boolean delete;
   public static String input;
   public static boolean Input;
    //////////////////////////////////////////////
    public static void ExitStudentApplication()
    {
        System.out.println("GOODBYE");
        System.exit(0);
    }
    /////////////////////////////////
     public  static void studentCapture() 
    {
        
        
        Scanner kb = new Scanner(System.in);
        
        
        System.out.println("CAPTURE NEW STUDENT\n"
                + "******************************");
        System.out.println("Enter the student ID: ");
        Id = kb.nextInt(); //enter variable
        ID.add(Id);      //add variable to ArrayList
        System.out.println("Enter the student name:");
        Name = kb.next();   //enter variable
        name.add(Name);   //add variable to ArrayList
        System.out.println("Enter the student age:");
        Age = kb.nextInt();    //enter variable
        while(Age < 16) 
        {
            System.out.println("You have entered an incorrect/invalid student age!!!");
            System.out.println("Please only enter numbers(no letters).");
            System.out.println("Please re-enter the student age>>");
            Age = kb.nextInt();
        }
        AGE = true;
        age.add(Age);       //add variable to ArrayList
        System.out.println("Enter the student email:");
        Email = kb.next();   //enter variable
        email.add(Email);   //add variable to ArrayList
        System.out.println("Enter the student course:");
        Course = kb.next();   //enter variable
        course.add(Course);   //add variable to ArrayList
        
        studentCount = studentCount + 1;
         
    }

    public static String getName() {
        return Name;
    }

    public static int getAge() {
        return Age;
    }

    public static String getCourse() {
        return Course;
    }

    public static String getEmail() {
        return Email;
    }

    public static int getId() {
        return Id;
    }
    
        public static void setName(String Name) {
        Student.Name = Name;
    }

    public static void setAge(int Age) {
        Student.Age = Age;
    }

    public static void setCourse(String Course) {
        Student.Course = Course;
    }

    public static void setEmail(String Email) {
        Student.Email = Email;
    }

    public static void setId(int Id) {
        Student.Id = Id;
    }
//////////////////////////////////////////////////////////////////////
    public static boolean studentSearch() 
    {
        Scanner kb = new Scanner(System.in);
        int studentID;
        boolean found = false;
        System.out.println("Enter the student id to search: ");
        System.out.println("-----------------------------------");
        studentID = kb.nextInt();
        
        for (int i = 0; i < ID.size(); i++) 
        {
            if (studentID == ID.get(i)) 
            {
                System.out.println("STUDENT ID: " + ID.get(i));
                System.out.println("STUDENT NAME: " + name.get(i));
                System.out.println("STUDENT AGE: " + age.get(i));
                System.out.println("STUDENT EMAIL: " + email.get(i));
                System.out.println("STUDENT COURSE: " + course.get(i));
                System.out.println("-----------------------------------\n");
            }
            else {System.out.println("Student with ID: "+studentID+" was not found.");
                  System.out.println("-----------------------------------\n");}
        }
        
        return found = true;
    }


//////////////////////////////////////////////////////////////////
    
    public static boolean deleteStudent() 
    { 
        
        Scanner kb = new Scanner(System.in);
        int id;
        String input = "";
        System.out.println("Enter the student id to delete");
        id = kb.nextInt();
        System.out.println("Are you sure you want to delete student "+id+ " from the system,\n"
                + " enter (Y) to confirm or enter (N) to cancel");
        input = kb.next();
        System.out.println("-----------------------------------");
        if (input.contains("Y")) 
        {
            Input = true;
            for (int i = 0; i < ID.size(); i++) 
            {
            if (id == ID.get(i)) 
            {
                name.remove(i);
                ID.remove(i);
                course.remove(i);
                email.remove(i);
                age.remove(i);       
            }
            delete = true;
            }
            System.out.println("Student with student id: "+ id +" has been deleted.\n\n");
            Count = Count - 1;
        }
        return true;
        
        
    }
///////////////////////////////////////////////
    public static void studentReport() 
    {
        int count = 0;
        
        while(Count <= studentCount)
        {
        System.out.println("STUDENT "+Count);
        System.out.println("---------------------------------");
        System.out.println("STUDENT ID: " +ID.get(count));
        System.out.println("STUDENT NAME: " +name.get(count));
        System.out.println("STUDENT AGE: "+age.get(count));
        System.out.println("STUDENT EMAIL: "+email.get(count));
        System.out.println("STUDENT COURSE: "+course.get(count));
        System.out.println("---------------------------------\n");
        Count = Count + 1;
        count = count + 1;
        }   
    }
    //////////////////////////////////////////////////////////////////////////////////
    public static void menu()
    {
     Scanner kb = new Scanner(System.in);
        System.out.println("\nSTUDENT MANAGEMENT APPLICATION");
        System.out.println("**************************************");
        System.out.println("Enter (1) to launch menu or any other number to exit\n");
         userInput = kb.nextInt();
         
           if (userInput == 1) 
        {
           System.out.println("Please select one of the following menu items:\n"
                    + "(1) Capture a new student.\n"
                    + "(2) Search for a student\n"
                    + "(3) Delete a student\n"
                    + "(4) Print student report\n"
                    + "(5) Exit Application\n"); 
           
        } 
        else 
        {
            System.out.println("\nGoodbye");
            System.exit(0);
        }        
    }
    ////////////////////////////////////////////////////////////////////////////////////
}
