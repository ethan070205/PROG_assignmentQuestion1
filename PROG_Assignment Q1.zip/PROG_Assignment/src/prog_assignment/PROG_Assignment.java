/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog_assignment;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author User
 */

public class PROG_Assignment {

    /**
     * @param args the command line arguments
     */
    public static ArrayList<String> name = new ArrayList<>();
    public static ArrayList<Integer> ID = new ArrayList<>();
    public static ArrayList<Integer> age = new ArrayList<>();
    public static ArrayList<String> email = new ArrayList<>();
    public static ArrayList<String> course = new ArrayList<>();
    public static int studentCount = 0;
    public static int userInput;
    public static int menuInput;
    public static int Count = 1;
    
    public static void main(String[] args) 
    {
        Scanner kb = new Scanner(System.in);
       
        Student.menu();
       menuInput = kb.nextInt();
       
       while (userInput == 1){
       switch(menuInput){
           case 1 : Student.studentCapture();
                    Student.menu();
                    menuInput = kb.nextInt();
                    break;
                    
           case 2 : Student.studentSearch(); 
                    Student.menu();
                    menuInput = kb.nextInt();
                    break;
                    
           case 3 : Student.deleteStudent();
                    Student.menu();
                    menuInput = kb.nextInt();
                    break;
                    
           case 4 : Student.studentReport();
                    Student.menu();
                    menuInput = kb.nextInt();
                    break;
                    
           case 5 : Student.ExitStudentApplication(); 
                    break;
                    
          default : System.out.println("please enter a valid input.");
                    Student.menu();
                    menuInput = kb.nextInt();
                    break;
            
       }
    }
    }
    
    
}
